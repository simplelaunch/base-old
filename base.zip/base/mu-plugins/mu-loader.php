<?php
require WPMU_PLUGIN_DIR.'/site-optimizer.php';
/* Test change */