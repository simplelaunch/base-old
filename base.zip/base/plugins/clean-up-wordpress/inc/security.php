<?php
/*
 * Removes the generator tag with WP version numbers. Hackes will use this to find weak and old WP installs
 */
add_filter( 'the_generator', 'no_generator' );
function no_generator()  {
	return '';
}


/*
 * Clean up wp_head() from unused or unsecure stuff
 */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);


/*
 * Show less info to users on failed login for security.
 * (Will not let a valid username be known.)
 */
add_filter( 'login_errors', 'show_less_login_info' );
function show_less_login_info() {
	return "<strong>ERROR</strong>: Stop guessing!";
}

/*
 * Pick out the version number from scripts and styles
 */
add_filter( 'style_loader_src', 'remove_version_from_style_js' );
add_filter( 'script_loader_src', 'remove_version_from_style_js' );
function remove_version_from_style_js( $src ) {
	if ( strpos( $src, 'ver=' . get_bloginfo( 'version' ) ) ) {
		$src = remove_query_arg( 'ver', $src );
	}

	return $src;
}
