<?php
/**
 * Plugin Name: Clean Up Wordpress
 * Plugin URI: http://mizner.io
 * Description:
 * Version: 1.0
 * Author: Michael Mizner
 * Author URI: http://mizner.io
 * License:
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

include( 'inc/removals.php' );
include ('inc/security.php');
include ('inc/dequeue.php');